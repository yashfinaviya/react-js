import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { deleteBookAsync, getAllBooks, getAllBooksAsync } from "../services/actions/library.action";
import { useState } from 'react';
import { Button, Card, Container, Form, Dropdown, Col } from 'react-bootstrap';
import { useNavigate } from "react-router";
import { FaEdit, FaEye, FaTrash } from "react-icons/fa";
// import './blog.css';

function Home() {
  const { books, isLoading } = useSelector((state) => state.bookReducer);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleEdit = (id) => {
    navigate(`/edit/${id}`);
  };
  const handleDelete = (id) => {
    dispatch(deleteBookAsync(id));
  };

  useEffect(() => {
    dispatch(getAllBooksAsync());
  }, []);
  return (
    <div>
      {isLoading ? <h2>Loading....</h2> : books.length == 0 ? (
        <h4>Data Not Found</h4>
      ) : (
        <Container className='d-flex flex-wrap mt-2'>
          {books.map((book) => (
            <Col xl={4}>
              <Card className="card"
                style={{
                  width: "100%",
                  margin: "10px",
                }}
              >
                <Card.Img
                  variant="top"
                  src={book.img}
                  className="img"
                  style={{
                    width: "100%",
                    height: "300px",
                    objectFit: "cover",
                  }}
                />
                <Card.Body className="body">
                  <Card.Title>
                    <div>
                      <h5 className="title text-success fw-bolder">Title:<span className="text-secondary fs-4 fw-normal">{book.title}</span></h5>
                    </div>
                  </Card.Title>
                  <Card.Text>
                    <h5 className="desc text-success fw-bolder">Author: <span className="text-secondary fs-4 fw-normal">{book.author}</span></h5>
                    <h5 className="price text-success fw-bolder">Edition: <span className="text-secondary fs-4 fw-normal">{book.edition}</span></h5>
                    <h5 className="price text-success fw-bolder">Publication: <span className="text-secondary fs-4 fw-normal">{book.publication}</span></h5>
                    <h5 className="price text-success fw-bolder">Date: <span className="text-secondary fs-4 fw-normal">{book.date}</span></h5>
                  </Card.Text>
                  <Button className="edit me-3"
                    onClick={() => handleEdit(book.id)}
                    variant="warning"
                  >
                    <FaEdit className="editbtn" />
                  </Button>{" "}
                  <Button
                    className="delete"
                    onClick={() => handleDelete(book.id)}
                    variant="danger"
                  >
                    <FaTrash className="deletebtn" />
                  </Button>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Container>
      )}
    </div>
  );
}

export default Home;