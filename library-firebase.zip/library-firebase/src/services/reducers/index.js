import { combineReducers } from "redux";
import { bookReducer } from "./LibraryReducer";


export const rootReducer = combineReducers({
    bookReducer
})